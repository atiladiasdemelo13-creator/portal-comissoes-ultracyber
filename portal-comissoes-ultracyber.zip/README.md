# Portal de Comissões — Ultra Cyber Security

Portal de comissionamento em cascata para representantes e sub-representantes.

- **Site:** arquivos estáticos (`index.html`, `app.js`, `estilo.css`, `config.js`), publicados na **Vercel**.
- **Banco, login e regras:** **Supabase** (`supabase/instalar.sql`). Todo cálculo de comissão e toda regra de "quem vê o quê" roda no banco — o site só exibe.

## Regras implementadas

1. Cliente é solicitado pelo representante e só entra na carteira após **aceite do gestor** (recusa exige motivo). Um CNPJ pertence a uma única carteira; nova tentativa é bloqueada e gera alerta.
2. NF é lançada para um cliente aprovado; o representante dono da carteira é reconhecido pelo CNPJ.
3. Comissão só é gerada quando a **parcela é recebida**.
4. **Base = valor recebido − impostos** do regime vigente (Simples, Presumido ou Real — alíquotas editáveis e obrigatórias).
5. **Cascata:** cada representante tem um % global. Quem está abaixo tira do % de quem está acima, só nos clientes de quem está abaixo. Ex.: A 20%, B 15%, C 10% → num cliente do C: C 10%, B 5%, A 5%.
6. **Regra específica por cliente** se sobressai ao cadastro só naquele cliente (ex.: 25% no topo).
7. Ninguém pode ter % maior que o superior; topo limitado a 50%. Só o gestor altera.
8. Cancelamento: comissão não paga é estornada; já paga vira desconto no próximo pagamento.
9. Cada representante vê a si e tudo abaixo; **nunca vê quem está acima** (garantido no banco por Row Level Security).
10. Toda alteração fica na auditoria.

---

## Instalação (cerca de 20 minutos)

### 1. Supabase — banco de dados e login

1. Acesse **supabase.com** → **Start your project** → **Continue with GitHub**.
2. **New project**:
   - Name: `portal-comissoes`
   - Database password: clique em **Generate a password** e guarde num lugar seguro.
   - Region: **South America (São Paulo)**.
   - Clique em **Create new project** e aguarde 1–2 minutos.
3. Menu lateral → **SQL Editor** → **New query**. Abra o arquivo [`supabase/instalar.sql`](supabase/instalar.sql) aqui no GitHub, clique no botão **Copy raw file**, cole no editor e clique em **Run**. Deve aparecer "Success".
4. Ainda no SQL Editor, rode esta linha **com o seu e-mail** (é ele que vira o gestor master):
   ```sql
   insert into gestores (email) values ('seu-email@empresa.com.br');
   ```
5. Menu lateral → **Project Settings** → **API** (ou **Data API** / **API Keys**). Copie:
   - **Project URL** (algo como `https://abcd1234.supabase.co`)
   - **anon public** key (um texto longo começando com `eyJ...`, ou `sb_publishable_...`)

   ⚠️ **Nunca** copie nem compartilhe a chave **service_role** / **secret**.

### 2. Preencher o `config.js`

Abra [`config.js`](config.js) aqui no GitHub → ícone de lápis (**Edit**) → cole a URL e a chave anon entre as aspas → **Commit changes**.

(Ou mande a URL e a chave anon para o Claude, que ele preenche.)

### 3. Vercel — colocar o site no ar

1. Acesse **vercel.com** → **Sign Up** → **Continue with GitHub**.
2. **Add New… → Project** → escolha `portal-comissoes-ultracyber` → **Import**.
3. Framework Preset: **Other**. Não mude mais nada → **Deploy**.
4. Ao terminar, copie o endereço do site (ex.: `https://portal-comissoes-ultracyber.vercel.app`).

### 4. Liberar o login no endereço do site

No Supabase → **Authentication** → **URL Configuration**:
- **Site URL:** cole o endereço da Vercel.
- **Redirect URLs:** adicione o mesmo endereço.
- Clique em **Save**.

### 5. Primeiro acesso

Abra o endereço do site, digite o seu e-mail e clique no link que chegar. Pronto: você entra como gestor.

### 6. Antes de cadastrar representantes reais — e-mail de login (obrigatório)

O envio de e-mail padrão do Supabase **só entrega para membros da equipe do projeto e no máximo 2 e-mails por hora**. Para os representantes conseguirem entrar, configure um provedor de e-mail:

1. Crie conta gratuita num provedor SMTP (ex.: **Brevo** ou **Resend**) e valide o domínio `ultracyber...` (ou use o domínio de teste do provedor).
2. Supabase → **Authentication** → **Emails** → **SMTP Settings** → ative **Enable custom SMTP** e preencha host, porta, usuário e senha que o provedor fornecer.
3. Em **Authentication → Rate Limits**, ajuste o limite de e-mails por hora se precisar.

Enquanto isso não estiver feito, só você (dono do projeto) consegue receber o link de acesso.

---

## Uso diário

- **Gestor:** cadastra representantes (com e-mail), aceita/recusa clientes, lança NFs, registra recebimentos e pagamentos, ajusta impostos e regras por cliente, importa extrato OFX do Itaú.
- **Representante:** entra com o e-mail cadastrado, vê seus clientes em linha (recebido / a receber / aguardando pagamento), sua rede abaixo, o cálculo de cada comissão e solicita novos clientes.

## Custos

- **Teste:** planos gratuitos da Vercel (Hobby) e do Supabase (Free). O Supabase Free pausa o projeto após 7 dias sem uso (basta reativar no painel).
- **Produção:** Vercel Pro (US$ 20/mês por usuário da Vercel) + Supabase Pro (a partir de US$ 25/mês). O plano Hobby da Vercel não permite uso comercial.

## Próximas fases

- Integração com **Bling** ou **Conta Azul** (NF e baixas automáticas) via Edge Function do Supabase.
- Conexão automática com o **Itaú** (API do banco / Open Finance).
- Assistente de IA (perguntas sobre comissões e leitura de XML de NF).
- Domínio próprio (ex.: `comissoes.ultracyber.com.br`) — configurável na Vercel em Settings → Domains.

## Atualizar o banco

Se uma nova versão do `instalar.sql` for publicada, basta rodá-lo de novo no SQL Editor: ele não apaga dados.
