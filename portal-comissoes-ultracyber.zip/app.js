// Portal de Comissões — Ultra Cyber Security
// Site estático: toda regra de cálculo e de visibilidade roda no banco (Supabase, ver supabase/instalar.sql).
import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm';

const CFG = window.PORTAL_CONFIG || {};
const $ = id => document.getElementById(id);
const MAXPCT = 50;
const brl = v => (v < 0 ? '-' : '') + 'R$ ' + Math.abs(+v || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const pctf = v => Number(v || 0).toLocaleString('pt-BR', { maximumFractionDigits: 2 }) + '%';
const r2 = v => Math.round(v * 100) / 100;
const hojeLocal = () => { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 10); };
const hoje = hojeLocal;
const dbr = d => d ? String(d).slice(0, 10).split('-').reverse().join('/') : '—';
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const clampPct = v => Math.min(MAXPCT, Math.max(0, parseFloat(v) || 0));
const fmtCnpj = c => String(c).replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, '$1.$2.$3/$4-$5');
const ERPS = { bling: { nome: 'Bling', url: 'https://www.bling.com.br/' }, contaazul: { nome: 'Conta Azul', url: 'https://app.contaazul.com/' } };

function toast(m, k) {
  const t = $('toast'); t.textContent = m;
  t.style.background = k === 'ok' ? 'var(--okb)' : k === 'w' ? 'var(--warnb)' : 'var(--badb)';
  t.style.color = k === 'ok' ? 'var(--ok)' : k === 'w' ? 'var(--warn)' : 'var(--bad)';
  t.style.display = 'block'; clearTimeout(t._h); t._h = setTimeout(() => t.style.display = 'none', 7000);
}
const erroMsg = e => (e && (e.message || e.error_description)) || 'Erro inesperado.';

if (!CFG.SUPABASE_URL || !CFG.SUPABASE_ANON_KEY) {
  $('app').innerHTML = `<div class="card"><h2>Configuração pendente</h2><p>Preencha <b>config.js</b> com a URL e a chave <i>anon public</i> do Supabase (veja o README).</p></div>`;
  throw new Error('config.js não preenchido');
}
const sb = createClient(CFG.SUPABASE_URL, CFG.SUPABASE_ANON_KEY);

/* ================= Estado ================= */
let S = null, eu = null, tab = null, fsub = 'com', editRegra = null;
const user = () => eu?.papel === 'gestor' ? 'admin' : eu?.rep_id;

async function q(p) { const { data, error } = await p; if (error) throw error; return data; }
async function carregar() {
  const ehG = eu.papel === 'gestor';
  const [reps, clientes, regras, notas, parcelas, comissoes, config, conflitos, banco, aud, gestores] = await Promise.all([
    q(sb.from('representantes').select('*').order('criado_em')),
    q(sb.from('clientes').select('*').order('razao')),
    q(sb.from('regras_cliente').select('*')),
    q(sb.from('notas').select('*').order('criada_em')),
    q(sb.from('parcelas').select('*').order('n')),
    q(sb.from('comissoes').select('*').order('criada_em')),
    q(sb.from('config').select('*').eq('id', 1).single()),
    ehG ? q(sb.from('conflitos').select('*').order('quando')) : [],
    ehG ? q(sb.from('banco_lancamentos').select('*').order('data')) : [],
    ehG ? q(sb.from('auditoria').select('*').order('quando', { ascending: false }).limit(80)) : [],
    ehG ? q(sb.from('gestores').select('*')) : []
  ]);
  S = {
    config: { regime: config.regime, regimes: config.regimes },
    banco: { nome: config.banco_nome, saldoInicial: +config.saldo_inicial, fonte: config.banco_fonte, importadoEm: config.banco_importado_em,
      lancs: banco.map(l => ({ id: l.id, data: l.data, desc: l.descricao, valor: +l.valor, origem: l.origem })) },
    reps: reps.map(r => ({ id: r.id, nome: r.nome, email: r.email, parent: r.superior_id, pct: +r.pct, ativo: r.ativo })),
    clientes: clientes.map(c => {
      const rg = regras.filter(x => x.cnpj === c.cnpj);
      return { cnpj: c.cnpj, razao: c.razao, repId: c.rep_id, status: c.status, motivo: c.motivo, data: c.solicitado_em, decididoEm: c.decidido_em,
        regra: rg.length ? Object.fromEntries(rg.map(x => [x.rep_id, +x.pct])) : null };
    }),
    nfs: notas.map(n => ({ id: n.id, numero: n.numero, cnpj: n.cnpj, repId: n.rep_id, desc: n.descricao, total: +n.total, origem: n.origem,
      parcelas: parcelas.filter(p => p.nota_id === n.id).map(p => ({ id: p.id, n: p.n, valor: +p.valor, venc: p.vencimento, status: p.status, dataReceb: p.recebida_em, origemBaixa: p.origem_baixa })) })),
    comissoes: comissoes.map(c => ({ id: c.id, nfId: c.nota_id, parcela: c.parcela_n, repId: c.rep_id, nivel: c.nivel, tipo: c.tipo, recebido: +c.recebido,
      regime: c.regime, taxa: +c.taxa, impostos: +c.impostos, base: +c.base, pctGlobal: +c.pct_global, pctAbaixo: +c.pct_abaixo, pct: +c.pct,
      especifica: c.especifica, valor: +c.valor, status: c.status, estorno: c.estorno, dataPag: c.paga_em })),
    conflitos: conflitos.map(c => ({ cnpj: c.cnpj, dono: c.dono, tentou: c.tentou, data: c.quando })),
    auditoria: aud.map(a => ({ data: new Date(a.quando).toLocaleString('pt-BR'), quem: a.quem, txt: a.texto })),
    gestores: gestores.map(g => g.email)
  };
}

/* ================= Auxiliares de dados ================= */
const taxa = () => r2(S.config.regimes[S.config.regime].itens.reduce((s, i) => s + (+i.v || 0), 0));
const regimeNome = () => S.config.regimes[S.config.regime].nome;
const rep = id => S.reps.find(r => r.id === id);
const cliente = cnpj => S.clientes.find(c => c.cnpj === cnpj);
const filhos = id => S.reps.filter(r => r.parent === id);
function desc(id) { const out = [id]; filhos(id).forEach(r => out.push(...desc(r.id))); return out; }
function visiveis() { return user() === 'admin' ? S.reps.map(r => r.id) : desc(user()); }
function nivelDe(id) { let n = 0, r = rep(id); while (r && r.parent && rep(r.parent)) { n++; r = rep(r.parent); } return n; }
function subida(repId) { const out = []; let r = rep(repId); while (r) { out.push(r); r = rep(r.parent); } return out; }
const saldoBanco = () => r2(S.banco.saldoInicial + S.banco.lancs.reduce((s, l) => s + l.valor, 0));
function saldo(repId, st) { return r2(S.comissoes.filter(c => c.repId === repId && c.status === st).reduce((s, c) => s + c.valor, 0)); }
function pctNaCadeia(r, cli) { return cli && cli.regra && cli.regra[r.id] != null ? cli.regra[r.id] : r.pct; }
function cadeia(repId, cnpj) {
  const cli = cliente(cnpj), ch = subida(repId);
  return ch.map((r, i) => {
    const p = pctNaCadeia(r, cli), abaixo = i > 0 ? pctNaCadeia(ch[i - 1], cli) : 0;
    return { repId: r.id, nivel: i, pctGlobal: p, pctAbaixo: abaixo, pct: r2(Math.max(0, p - abaixo)), especifica: !!(cli && cli.regra && cli.regra[r.id] != null) };
  });
}
const totalCadeia = (repId, cnpj) => { const c = cadeia(repId, cnpj); return c.length ? c[c.length - 1].pctGlobal : 0; };
function cadeiaValida(repId, cnpj) {
  const ch = subida(repId), cli = cliente(cnpj);
  for (let i = 1; i < ch.length; i++) if (pctNaCadeia(ch[i], cli) < pctNaCadeia(ch[i - 1], cli)) return false;
  return totalCadeia(repId, cnpj) <= MAXPCT;
}
function addDias(d, n) { const x = new Date(d + 'T12:00:00'); x.setDate(x.getDate() + n); return x.toISOString().slice(0, 10); }

/* ================= Resumo por cliente ================= */
function resumoClientes() {
  const vis = visiveis();
  return S.clientes.filter(c => vis.includes(c.repId) && c.status === 'aprovado').map(c => {
    const nfs = S.nfs.filter(n => n.cnpj === c.cnpj), ps = nfs.flatMap(n => n.parcelas);
    const sum = st => r2(ps.filter(p => p.status === st).reduce((s, p) => s + p.valor, 0));
    const atras = ps.some(p => p.status === 'aberta' && p.venc < hoje());
    const cs = S.comissoes.filter(x => nfs.some(n => n.id === x.nfId) && (user() === 'admin' || x.repId === user()));
    const cst = st => r2(cs.filter(x => x.status === st).reduce((s, x) => s + x.valor, 0));
    return { c, faturado: r2(sum('aberta') + sum('recebida')), recebido: sum('recebida'), aReceber: sum('aberta'), atras, aguard: cst('a pagar'), pago: cst('paga') };
  });
}
function tabResumo() {
  const rs = resumoClientes(); if (!rs.length) return '<p class="muted">Nenhum cliente aprovado.</p>';
  const lbl = user() === 'admin' ? 'Comissões' : 'Sua comissão';
  return `<table><tr><th>Cliente</th><th>Representante</th><th class="n">Faturado</th><th class="n">Recebido</th><th class="n">A receber</th><th class="n">${lbl} aguardando pagto.</th><th class="n">${lbl} paga</th><th>Status</th></tr>` +
    rs.map(r => {
      const tags = [];
      if (r.recebido > 0) tags.push('<span class="tag t-ok">recebido</span>');
      if (r.aReceber > 0) tags.push(`<span class="tag ${r.atras ? 't-b' : 't-w'}">${r.atras ? 'a receber — vencido' : 'a receber'}</span>`);
      if (r.aguard > 0) tags.push('<span class="tag t-p">aguardando pagamento</span>');
      if (r.c.regra) tags.push('<span class="tag">regra específica</span>');
      if (!tags.length) tags.push('<span class="tag">sem movimento</span>');
      return `<tr><td><b>${esc(r.c.razao)}</b><br><span class="muted">${fmtCnpj(r.c.cnpj)}</span></td><td>${esc(rep(r.c.repId)?.nome)}</td>
      <td class="n">${brl(r.faturado)}</td><td class="n">${brl(r.recebido)}</td><td class="n">${brl(r.aReceber)}</td><td class="n">${brl(r.aguard)}</td><td class="n">${brl(r.pago)}</td><td>${tags.join('')}</td></tr>`;
    }).join('') + '</table>';
}

/* ================= Componentes ================= */
function formulaPct(c) { return c.nivel === 0 ? pctf(c.pct) : `(${pctf(c.pctGlobal)} − ${pctf(c.pctAbaixo)}) = ${pctf(c.pct)}`; }
function linhasHtml(cs, mostrarNF) {
  if (!cs.length) return '<p class="muted">Nenhum lançamento.</p>';
  return `<table><tr>${mostrarNF ? '<th>NF / parcela</th>' : ''}<th>Representante</th><th>Tipo</th><th>Fórmula: (recebido − impostos) × %</th><th class="n">Comissão</th><th>Status</th></tr>` +
    cs.map(c => {
      const nf = S.nfs.find(x => x.id === c.nfId);
      const st = c.status === 'paga' ? `<span class="tag t-ok">paga ${dbr(c.dataPag)}</span>` : c.status === 'estornada' ? '<span class="tag t-b">estornada</span>' : '<span class="tag t-p">aguardando pagamento</span>';
      return `<tr>${mostrarNF ? `<td>NF ${esc(nf?.numero)} · ${c.parcela}ª</td>` : ''}<td>${esc(rep(c.repId)?.nome)}${c.repId === user() ? ' <span class="tag t-p">você</span>' : ''}</td>
      <td>${esc(c.tipo)}${c.especifica ? ' <span class="tag">regra do cliente</span>' : ''}</td>
      <td class="formula">(${brl(c.recebido)} − ${pctf(c.taxa)} ${esc(c.regime)} = ${brl(c.base)}) × ${formulaPct(c)}</td><td class="n">${brl(c.valor)}</td><td>${st}</td></tr>`;
    }).join('') + '</table>';
}
function nfsHtml(nfs, admin) {
  if (!nfs.length) return '<p class="muted">Nenhuma nota.</p>';
  const vis = visiveis();
  return nfs.map(nf => {
    const cli = cliente(nf.cnpj);
    const parc = nf.parcelas.map(p => {
      const venc = p.status === 'aberta' && p.venc < hoje();
      const st = p.status === 'recebida' ? `<span class="tag t-ok">recebida ${dbr(p.dataReceb)}</span>${p.origemBaixa && p.origemBaixa !== 'manual' ? ` <span class="tag t-p">baixa via ${esc(p.origemBaixa)}</span>` : ''}`
        : p.status === 'cancelada' ? '<span class="tag t-b">cancelada</span>' : `<span class="tag ${venc ? 't-b' : 't-w'}">a receber ${dbr(p.venc)}${venc ? ' — vencida' : ''}</span>`;
      let acts = '';
      if (admin) {
        if (p.status === 'aberta') acts += `<button class="s" data-a="receber" data-id="${p.id}">Registrar recebimento</button> `;
        if (p.status !== 'cancelada') acts += `<button class="s bad" data-a="cancelar" data-id="${p.id}">Cancelar / estornar</button>`;
      }
      const cs = S.comissoes.filter(c => c.nfId === nf.id && c.parcela === p.n && vis.includes(c.repId));
      return `<tr><td>${p.n}ª</td><td class="n">${brl(p.valor)}</td><td>${st}</td><td>${acts}</td></tr>
      ${cs.length ? `<tr><td></td><td colspan="3"><details><summary>Cálculo das comissões desta parcela (${cs.length})</summary>${linhasHtml(cs, false)}</details></td></tr>` : ''}`;
    }).join('');
    return `<div class="card"><h2>NF ${esc(nf.numero)} — ${esc(cli?.razao)} <span class="muted">(${fmtCnpj(nf.cnpj)})</span> ${nf.origem !== 'manual' ? `<span class="tag t-p">importada do ${esc(nf.origem)}</span>` : ''}</h2>
      <p class="muted" style="margin-top:-6px">${esc(nf.desc)} · Valor total ${brl(nf.total)} · Representante: <b>${esc(rep(nf.repId)?.nome)}</b></p>
      <table><tr><th>Parcela</th><th class="n">Valor</th><th>Situação</th><th></th></tr>${parc}</table></div>`;
  }).join('');
}
function arvore(rootIds) {
  const node = id => {
    const r = rep(id), fs = filhos(id);
    const gerado = r2(S.comissoes.filter(c => c.repId === id && c.status !== 'estornada').reduce((s, c) => s + c.valor, 0));
    const p = rep(r.parent), mostraPai = p && (user() === 'admin' || desc(user()).includes(p.id));
    return `<li><span class="node ${id === user() ? 'me' : ''}"><b>${esc(r.nome)}</b>
      <span class="tag t-p">${pctf(r.pct)} global</span>
      ${mostraPai ? `<span class="muted">superior fica com ${pctf(Math.max(0, p.pct - r.pct))} nos clientes dele</span>` : ''}
      <span class="muted">comissões: ${brl(gerado)}</span></span>
      ${fs.length ? '<ul>' + fs.map(f => node(f.id)).join('') + '</ul>' : ''}</li>`;
  };
  return '<ul class="tree">' + rootIds.map(node).join('') + '</ul>';
}
const kpiImposto = () => `<div class="kpi"><span>Impostos descontados da base</span><b>${pctf(taxa())}</b><small> ${esc(regimeNome())}</small></div>`;
const linksErp = () => `<div class="row">${Object.values(ERPS).map(e => `<a class="lk" href="${e.url}" target="_blank" rel="noopener">Abrir ${e.nome} ↗</a>`).join('')}<a class="lk" href="https://www.itau.com.br/empresas" target="_blank" rel="noopener">Abrir Itaú Empresas ↗</a></div>`;
function meses() { const out = []; const d = new Date(hoje() + 'T12:00:00'); d.setDate(1); d.setMonth(d.getMonth() - 1); for (let i = 0; i < 5; i++) { out.push(d.toISOString().slice(0, 7)); d.setMonth(d.getMonth() + 1); } return out; }
const nomeMes = m => { const [y, mm] = m.split('-'); return ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'][+mm - 1] + '/' + y.slice(2); };
function formCliente(admin) {
  return `<form class="row" data-f="cli"><label>CNPJ<input name="cnpj" required placeholder="00.000.000/0000-00"></label>
  <label>Razão social<input name="razao" required style="width:240px"></label>
  ${admin ? `<label>Carteira de<select name="repId">${S.reps.map(r => `<option value="${r.id}">${esc(r.nome)}</option>`).join('')}</select></label>` : ''}
  <button class="b">${admin ? 'Cadastrar' : 'Enviar para aceite'}</button></form>`;
}

/* ================= Telas — Financeiro ================= */
const FIN = {
  com() {
    const parcelas = S.nfs.flatMap(nf => nf.parcelas.map(p => ({ ...p, nf })));
    const aRec = r2(parcelas.filter(p => p.status === 'aberta').reduce((s, p) => s + p.valor, 0));
    const aPag = r2(S.comissoes.filter(c => c.status === 'a pagar').reduce((s, c) => s + c.valor, 0));
    const pag = r2(S.comissoes.filter(c => c.status === 'paga').reduce((s, c) => s + c.valor, 0));
    return `<div class="kpis"><div class="kpi"><span>Contas a receber</span><b>${brl(aRec)}</b></div>
      <div class="kpi"><span>Comissões a pagar</span><b>${brl(aPag)}</b></div><div class="kpi"><span>Comissões pagas</span><b>${brl(pag)}</b></div>${kpiImposto()}</div>
    <div class="card"><h2>Contas a pagar — comissões por representante</h2>
      <table><tr><th>Representante</th><th>Superior</th><th class="n">A pagar (líquido)</th><th class="n">Já pago</th><th></th></tr>
      ${S.reps.map(r => { const ap = saldo(r.id, 'a pagar'), pg = saldo(r.id, 'paga'); return `<tr><td>${'— '.repeat(nivelDe(r.id))}${esc(r.nome)}</td><td class="muted">${esc(rep(r.parent)?.nome || '—')}</td>
        <td class="n">${brl(ap)}</td><td class="n">${brl(pg)}</td><td><button class="s" data-a="pagar" data-id="${r.id}" ${ap <= 0 ? 'disabled' : ''}>Registrar pagamento</button></td></tr>`; }).join('')}
      </table><p><button class="s" data-a="csv">Copiar contas a pagar (CSV)</button></p>
      <p class="note">O pagamento em si é feito no banco/ERP. Aqui se registra a baixa, para o representante ver o status.</p></div>
    <div class="card"><h2>Contas a receber — parcelas em aberto</h2>
      <table><tr><th>NF</th><th>Cliente</th><th>Parcela</th><th>Vencimento</th><th class="n">Valor</th></tr>
      ${parcelas.filter(p => p.status === 'aberta').sort((a, b) => a.venc.localeCompare(b.venc)).map(p => `<tr><td>${esc(p.nf.numero)}</td>
        <td>${esc(cliente(p.nf.cnpj)?.razao)}</td><td>${p.n}ª</td><td>${dbr(p.venc)}${p.venc < hoje() ? ' <span class="tag t-b">vencida</span>' : ''}</td><td class="n">${brl(p.valor)}</td></tr>`).join('') || '<tr><td colspan="5" class="muted">Nada em aberto.</td></tr>'}
      </table></div>`;
  },
  fluxo() {
    const ms = meses(), cur = hoje().slice(0, 7); let saldoProj = saldoBanco();
    const linhas = ms.map(m => {
      const lm = S.banco.lancs.filter(l => String(l.data).slice(0, 7) === m);
      const entR = r2(lm.filter(l => l.valor > 0).reduce((s, l) => s + l.valor, 0)), saiR = r2(lm.filter(l => l.valor < 0).reduce((s, l) => s + l.valor, 0));
      let entP = 0, saiP = 0;
      if (m >= cur) {
        const ps = S.nfs.flatMap(nf => nf.parcelas.filter(p => p.status === 'aberta' && (p.venc.slice(0, 7) === m || (m === cur && p.venc.slice(0, 7) < cur))).map(p => ({ p, nf })));
        entP = r2(ps.reduce((s, x) => s + x.p.valor, 0));
        const comFut = ps.reduce((s, x) => s + x.p.valor * (1 - taxa() / 100) * totalCadeia(x.nf.repId, x.nf.cnpj) / 100, 0);
        const comAberta = m === cur ? S.comissoes.filter(c => c.status === 'a pagar').reduce((s, c) => s + c.valor, 0) : 0;
        saiP = -r2(comFut + comAberta); saldoProj = r2(saldoProj + entP + saiP);
      }
      return `<tr><td>${nomeMes(m)}${m === cur ? ' <span class="tag t-p">atual</span>' : ''}</td><td class="n pos">${brl(entR)}</td><td class="n neg">${brl(saiR)}</td>
        <td class="n">${m >= cur ? brl(entP) : '—'}</td><td class="n">${m >= cur ? brl(saiP) : '—'}</td><td class="n"><b>${m >= cur ? brl(saldoProj) : '—'}</b></td></tr>`;
    }).join('');
    return `<div class="card"><h2>Fluxo de caixa</h2>
    <table><tr><th>Mês</th><th class="n">Entradas realizadas</th><th class="n">Saídas realizadas</th><th class="n">Entradas previstas</th><th class="n">Saídas previstas (comissões)</th><th class="n">Saldo projetado</th></tr>${linhas}</table>
    <p class="note">Ponto de partida: saldo bancário atual (${brl(saldoBanco())}). Previsto = parcelas em aberto por vencimento (vencidas entram no mês atual) e as comissões que elas vão gerar, mais as comissões já a pagar.</p></div>`;
  },
  banco() {
    const b = S.banco;
    return `<div class="kpis"><div class="kpi"><span>Saldo bancário — ${esc(b.nome)}</span><b>${brl(saldoBanco())}</b><small> ${b.fonte === 'ofx' ? 'extrato importado em ' + dbr(b.importadoEm) : 'registrado pelo portal'}</small></div></div>
    <div class="card"><h2>Atualizar pelo extrato</h2>
    <p>Exporte o extrato do Itaú em OFX (internet banking → Extrato → Exportar) e importe aqui. Os lançamentos do extrato substituem os registrados pelo portal.</p>
    <div class="row"><input type="file" id="ofx" accept=".ofx,.OFX,text/plain"> <button class="s" data-a="ofx">Importar extrato OFX</button></div>
    <p class="note">Conexão automática com o Itaú (API do banco ou Open Finance) fica para a próxima fase.</p>${linksErp()}</div>`;
  },
  es() {
    const ls = S.banco.lancs.slice().sort((a, b) => String(b.data).localeCompare(String(a.data)));
    const ent = r2(ls.filter(l => l.valor > 0).reduce((s, l) => s + l.valor, 0)), sai = r2(ls.filter(l => l.valor < 0).reduce((s, l) => s + l.valor, 0));
    return `<div class="kpis"><div class="kpi"><span>Entradas</span><b class="pos">${brl(ent)}</b></div><div class="kpi"><span>Saídas</span><b class="neg">${brl(sai)}</b></div><div class="kpi"><span>Resultado</span><b>${brl(r2(ent + sai))}</b></div></div>
    <div class="card"><h2>Entradas e saídas — global</h2><table><tr><th>Data</th><th>Descrição</th><th>Origem</th><th class="n">Valor</th></tr>
    ${ls.map(l => `<tr><td>${dbr(l.data)}</td><td>${esc(l.desc)}</td><td><span class="tag">${esc(l.origem)}</span></td><td class="n ${l.valor < 0 ? 'neg' : 'pos'}">${brl(l.valor)}</td></tr>`).join('') || '<tr><td colspan="4" class="muted">Sem lançamentos.</td></tr>'}</table></div>`;
  }
};

/* ================= Telas ================= */
const V = {
  fin() {
    const subs = [['com', 'Comissões e contas'], ['fluxo', 'Fluxo de caixa'], ['banco', 'Saldo bancário'], ['es', 'Entradas e saídas']];
    return `<div class="row" style="justify-content:space-between;margin-bottom:12px"><div class="sub" style="margin:0">${subs.map(([k, l]) => `<button data-fsub="${k}" class="${k === fsub ? 'on' : ''}">${l}</button>`).join('')}</div>${linksErp()}</div>${FIN[fsub]()}`;
  },
  cli() {
    return `${user() === 'admin' ? '' : `<div class="kpis"><div class="kpi"><span>Seu saldo aguardando pagamento</span><b>${brl(saldo(user(), 'a pagar'))}</b></div><div class="kpi"><span>Você já recebeu</span><b>${brl(saldo(user(), 'paga'))}</b></div>${kpiImposto()}</div>`}
    <div class="card"><h2>${user() === 'admin' ? 'Clientes — visão em linha' : 'Clientes da sua rede — visão em linha'}</h2>${tabResumo()}
    <p class="note">Recebido = o que a Ultra Cyber já recebeu do cliente. A receber = parcelas em aberto. Aguardando pagamento = comissão calculada e ainda não paga.</p></div>`;
  },
  aprov() {
    const pend = S.clientes.filter(c => c.status === 'pendente'), hist = S.clientes.filter(c => c.status !== 'pendente' && c.decididoEm);
    return `<div class="card"><h2>Clientes aguardando aceite</h2>
    ${pend.length ? `<table><tr><th>CNPJ</th><th>Cliente</th><th>Solicitado por</th><th>Data</th><th>Decisão</th></tr>${pend.map(c => `<tr><td>${fmtCnpj(c.cnpj)}</td><td>${esc(c.razao)}</td><td>${esc(rep(c.repId)?.nome)}<br><span class="muted">${subida(c.repId).slice(1).map(r => esc(r.nome)).join(' › ') || 'topo'}</span></td><td>${dbr(c.data)}</td>
      <td><div class="row"><button class="s" data-a="aceitar" data-cnpj="${c.cnpj}">Aceitar</button><input id="mot-${c.cnpj}" placeholder="Motivo da recusa (obrigatório)" style="width:230px"><button class="s bad" data-a="recusar" data-cnpj="${c.cnpj}">Recusar</button></div></td></tr>`).join('')}</table>` : '<p class="muted">Nenhuma solicitação pendente.</p>'}</div>
    <div class="card"><h2>Histórico de decisões</h2>${hist.length ? `<table><tr><th>Cliente</th><th>Representante</th><th>Decisão</th><th>Motivo</th><th>Em</th></tr>${hist.map(c => `<tr><td>${esc(c.razao)}</td><td>${esc(rep(c.repId)?.nome)}</td><td>${c.status === 'aprovado' ? '<span class="tag t-ok">aceito</span>' : '<span class="tag t-b">recusado</span>'}</td><td>${esc(c.motivo || '—')}</td><td>${dbr(c.decididoEm)}</td></tr>`).join('')}</table>` : '<p class="muted">Sem decisões ainda.</p>'}</div>`;
  },
  nfs() {
    const aprov = S.clientes.filter(c => c.status === 'aprovado');
    return `<div class="card"><h2>Lançamento de nota fiscal</h2>
    ${aprov.length ? `<form class="row" data-f="nf">
      <label>Nº da NF<input name="numero" required style="width:100px"></label>
      <label>Cliente aprovado<select name="cnpj" required>${aprov.map(c => `<option value="${c.cnpj}">${esc(c.razao)} — ${esc(rep(c.repId)?.nome)}</option>`).join('')}</select></label>
      <label>Descrição<input name="desc" value="Serviço de segurança da informação" style="width:230px"></label>
      <label>Valor total (R$)<input name="total" type="number" step="0.01" min="0.01" required style="width:120px"></label>
      <label>Parcelas<input name="np" type="number" min="1" max="60" value="1" style="width:70px"></label>
      <label>1º vencimento<input name="venc" type="date" value="${hoje()}"></label>
      <button class="b">Lançar NF</button></form>` : '<p class="muted">Cadastre e aprove um cliente primeiro.</p>'}
    <p class="note">O representante é reconhecido pela carteira do cliente. A comissão só nasce quando cada parcela é recebida, já descontados os impostos (${esc(regimeNome())}, ${pctf(taxa())}). A entrada automática pelo Bling/Conta Azul entra na próxima fase.</p></div>
    ${nfsHtml(S.nfs.slice().reverse(), true)}`;
  },
  reps() {
    const opts = r => { const proib = desc(r.id); return '<option value="">— (topo)</option>' + S.reps.filter(x => !proib.includes(x.id)).map(x => `<option value="${x.id}" ${x.id === r.parent ? 'selected' : ''}>${esc(x.nome)}</option>`).join(''); };
    return `<div class="grid2"><div class="card"><h2>Estrutura da rede</h2>${S.reps.length ? arvore(S.reps.filter(r => !r.parent).map(r => r.id)) : '<p class="muted">Nenhum representante.</p>'}</div>
    <div class="card"><h2>Novo representante</h2><form class="row" data-f="rep">
      <label>Nome<input name="nome" required></label>
      <label>E-mail (login)<input name="email" type="email" required style="width:220px"></label>
      <label>Superior<select name="parent"><option value="">— (topo)</option>${S.reps.map(r => `<option value="${r.id}">${esc(r.nome)} (${pctf(r.pct)})</option>`).join('')}</select></label>
      <label>% global<input name="pct" class="pct" type="number" step="0.01" min="0" max="${MAXPCT}" value="10"></label>
      <button class="b">Cadastrar</button></form>
      <p class="note">O representante entra no portal com este e-mail (recebe um link de acesso). O % de quem está abaixo sai do % do superior, só nos clientes de quem está abaixo. Ninguém pode ter mais que o superior; topo limitado a ${MAXPCT}%.</p></div></div>
    <div class="card"><h2>Representantes — somente o gestor altera</h2>
    <table><tr><th>Nome</th><th>E-mail</th><th>Superior</th><th class="n">% global</th><th class="n">Superior fica com</th></tr>
    ${S.reps.map(r => { const p = rep(r.parent); return `<tr><td><input data-e="nome" data-id="${r.id}" value="${esc(r.nome)}"></td><td><input data-e="email" data-id="${r.id}" value="${esc(r.email || '')}" style="width:200px"></td><td><select data-e="superior_id" data-id="${r.id}">${opts(r)}</select></td>
      <td class="n"><input class="pct" type="number" step="0.01" min="0" max="${MAXPCT}" data-e="pct" data-id="${r.id}" value="${r.pct}"></td>
      <td class="n">${p ? pctf(Math.max(0, p.pct - r.pct)) + ' (' + esc(p.nome) + ')' : '—'}</td></tr>`; }).join('')}</table>
    <p class="note">Alterações valem para os próximos recebimentos. Para aplicar às comissões ainda não pagas, use "Reprocessar" em Regras e impostos.</p></div>`;
  },
  cart() {
    const ap = S.clientes.filter(c => c.status === 'aprovado');
    return `<div class="card"><h2>Cadastrar cliente (gestor — entra já aceito)</h2>${S.reps.length ? formCliente(true) : '<p class="muted">Cadastre um representante primeiro.</p>'}</div>
    <div class="card"><h2>Carteiras e regras específicas por cliente</h2>
    ${ap.length ? `<table><tr><th>Cliente</th><th>Carteira</th><th>Divisão da comissão neste cliente</th><th class="n">Total</th><th></th></tr>
    ${ap.map(c => {
      const ch = cadeia(c.repId, c.cnpj), ok = cadeiaValida(c.repId, c.cnpj), edit = editRegra === c.cnpj;
      return `<tr><td><b>${esc(c.razao)}</b><br><span class="muted">${fmtCnpj(c.cnpj)}</span></td><td>${esc(rep(c.repId)?.nome)}</td>
      <td>${ch.map(l => `<span class="tag ${l.especifica ? 't-w' : 't-p'}">${esc(rep(l.repId).nome)}: ${pctf(l.pct)}</span>`).join('')}
        ${c.regra ? '<br><span class="tag t-w">regra específica deste cliente</span>' : ''}${ok ? '' : '<br><span class="tag t-b">inconsistente: nível abaixo maior que o de cima ou total acima de ' + MAXPCT + '%</span>'}</td>
      <td class="n">${pctf(totalCadeia(c.repId, c.cnpj))}</td><td><button class="s" data-a="editRegra" data-cnpj="${c.cnpj}">${edit ? 'Fechar' : 'Regra específica'}</button></td></tr>
      ${edit ? `<tr><td colspan="5"><div class="card" style="margin:0;background:var(--pri2)"><b>Regra específica para ${esc(c.razao)}</b> — se sobressai ao cadastro só neste cliente.
        <div class="row" style="margin-top:8px">${subida(c.repId).map(r => `<label class="muted" style="display:flex;flex-direction:column;font-size:12px">${esc(r.nome)} — % global neste cliente<input class="pct" type="number" step="0.01" min="0" max="${MAXPCT}" data-regra="${c.cnpj}" data-id="${r.id}" value="${pctNaCadeia(r, c)}"></label>`).join('')}
        <button class="s" data-a="limpaRegra" data-cnpj="${c.cnpj}">Voltar ao padrão</button></div>
        <p class="note">Cada um fica com a diferença para quem está abaixo. Ex.: para pagar 25% neste cliente, ponha 25% no topo.</p></div></td></tr>` : ''}`;
    }).join('')}</table>` : '<p class="muted">Nenhum cliente aprovado.</p>'}</div>
    <div class="card"><h2>Alertas de conflito de carteira</h2>
    ${S.conflitos.length ? `<table><tr><th>Data</th><th>CNPJ</th><th>Dono atual</th><th>Tentou cadastrar</th></tr>${S.conflitos.slice().reverse().map(c => `<tr><td>${dbr(c.data)}</td><td>${fmtCnpj(c.cnpj)}</td><td>${esc(rep(c.dono)?.nome)}</td><td><span class="tag t-b">${esc(rep(c.tentou)?.nome)}</span></td></tr>`).join('')}</table>` : '<p class="muted">Nenhum conflito registrado.</p>'}</div>`;
  },
  cfg() {
    const rg = S.config.regimes[S.config.regime];
    return `<div class="card"><h2>Regime tributário e impostos (obrigatório)</h2>
    <form class="row" data-f="cfg"><label>Regime da Ultra Cyber<select name="regime">${Object.entries(S.config.regimes).map(([k, v]) => `<option value="${k}" ${k === S.config.regime ? 'selected' : ''}>${v.nome}</option>`).join('')}</select></label><button class="b">Trocar regime</button></form>
    <h3>Composição — ${esc(rg.nome)}</h3>
    <table><tr><th>Tributo</th><th class="n">Alíquota sobre o recebido</th></tr>
    ${rg.itens.map((it, i) => `<tr><td>${esc(it.n)}</td><td class="n"><input class="pct" type="number" step="0.01" min="0" max="100" data-tx="${i}" value="${it.v}"></td></tr>`).join('')}
    <tr><td><b>Total descontado da base</b></td><td class="n"><b>${pctf(taxa())}</b></td></tr></table>
    <p class="note">Valores iniciais apenas ilustrativos — confirme cada número com a contabilidade. Não é possível registrar recebimento com total 0%. A alíquota usada fica gravada em cada comissão.</p>
    <h3>Reprocessar</h3><p><button class="s" data-a="reproc">Recalcular comissões ainda não pagas com as regras atuais</button></p></div>
    <div class="card"><h2>Gestores (acesso total)</h2>
    <table>${S.gestores.map(g => `<tr><td>${esc(g)}</td><td>${g.toLowerCase() === eu.email ? '<span class="tag t-p">você</span>' : `<button class="s bad" data-a="remGestor" data-email="${esc(g)}">Remover</button>`}</td></tr>`).join('')}</table>
    <form class="row" data-f="gestor" style="margin-top:8px"><label>E-mail<input name="email" type="email" required style="width:240px"></label><button class="b">Adicionar gestor</button></form></div>
    <div class="card"><h2>Auditoria (últimos 80 registros)</h2>${S.auditoria.length ? '<table><tr><th>Quando</th><th>Quem</th><th>O quê</th></tr>' + S.auditoria.map(a => `<tr><td class="muted">${esc(a.data)}</td><td class="muted">${esc(a.quem || '—')}</td><td>${esc(a.txt)}</td></tr>`).join('') + '</table>' : '<p class="muted">Sem registros.</p>'}</div>`;
  },
  integ() {
    return `<div class="card"><h2>Integrações — próxima fase</h2>
    <p>Quando o Bling (ou o Conta Azul) for assinado, a integração fará:</p>
    <table><tr><th>Do ERP para o portal</th><th>Do portal para o ERP</th></tr>
    <tr><td>NF emitida (número, CNPJ, valor, parcelas e vencimentos)</td><td>Contas a pagar das comissões</td></tr>
    <tr><td>Baixa de recebimento → gera as comissões</td><td>Baixa da comissão paga</td></tr>
    <tr><td>Cancelamento da NF → estorna as comissões</td><td></td></tr></table>
    <p class="note">Roda numa função do Supabase (Edge Function) que guarda o acesso ao ERP. Os representantes nunca acessam o ERP.</p>${linksErp()}</div>`;
  },
  rede() {
    const r = rep(user()), vis = visiveis();
    return `<div class="kpis"><div class="kpi"><span>Seu % global</span><b>${pctf(r.pct)}</b><small> nos seus clientes</small></div>${kpiImposto()}
      <div class="kpi"><span>Representantes abaixo</span><b>${vis.length - 1}</b></div></div>
    <div class="card"><h2>Sua rede</h2>${arvore([user()])}
    <p class="note">Nos clientes de quem está abaixo, você fica com a diferença entre o seu % e o dele. Clientes com regra específica podem ter outros percentuais — veja em "Recebimentos e cálculo".</p></div>
    <div class="card"><h2>Seu extrato</h2>${linhasHtml(S.comissoes.filter(c => c.repId === user()), true)}</div>`;
  },
  ext() {
    return `<div class="card"><h2>Recebimentos da empresa na sua rede</h2><p class="muted" style="margin:0">Notas da sua carteira e das carteiras abaixo, o que foi recebido, os impostos descontados (${esc(regimeNome())}, ${pctf(taxa())}) e o cálculo de cada comissão — a sua e a dos abaixo.</p></div>${nfsHtml(S.nfs.slice().reverse(), false)}`;
  },
  mcart() {
    const meus = S.clientes.filter(c => c.repId === user());
    return `<div class="card"><h2>Solicitar inclusão de cliente na sua carteira</h2>${formCliente(false)}
    <p class="note">O cliente entra como <b>aguardando aceite</b> e só vale depois que o gestor aceitar. Se o CNPJ já estiver em outra carteira, o pedido é bloqueado e a administração é avisada.</p></div>
    <div class="card"><h2>Suas solicitações</h2>${meus.length ? `<table><tr><th>CNPJ</th><th>Cliente</th><th>Situação</th><th>Motivo</th></tr>${meus.map(c => `<tr><td>${fmtCnpj(c.cnpj)}</td><td>${esc(c.razao)}</td><td>${c.status === 'aprovado' ? '<span class="tag t-ok">aceito</span>' : c.status === 'pendente' ? '<span class="tag t-w">aguardando aceite</span>' : '<span class="tag t-b">recusado</span>'}</td><td>${esc(c.motivo || '—')}</td></tr>`).join('')}</table>` : '<p class="muted">Nenhuma solicitação.</p>'}</div>`;
  }
};

function tabsDef() {
  const pend = S.clientes.filter(c => c.status === 'pendente').length;
  return user() === 'admin'
    ? [['fin', 'Financeiro'], ['cli', 'Clientes'], ['aprov', 'Aprovações' + (pend ? `<span class="badge">${pend}</span>` : '')], ['nfs', 'Notas e recebimentos'], ['reps', 'Representantes'], ['cart', 'Carteiras e regras por cliente'], ['cfg', 'Regras, impostos e gestores'], ['integ', 'Integrações']]
    : [['cli', 'Meus clientes'], ['rede', 'Minha rede'], ['ext', 'Recebimentos e cálculo'], ['mcart', 'Minha carteira']];
}
function render() {
  const t = tabsDef();
  if (!t.find(x => x[0] === tab)) tab = t[0][0];
  $('tabs').innerHTML = t.map(([k, l]) => `<button data-tab="${k}" class="${k === tab ? 'on' : ''}">${l}</button>`).join('');
  $('app').innerHTML = V[tab]();
}
async function atualizar(msg, k) { await carregar(); render(); if (msg) toast(msg, k || 'ok'); }
async function acao(fn) { try { await fn(); } catch (e) { toast(erroMsg(e), 'b'); try { await carregar(); render(); } catch (_) { } } }

/* ================= OFX ================= */
async function importarOfx() {
  const f = $('ofx').files[0]; if (!f) { toast('Escolha o arquivo OFX.', 'w'); return; }
  const t = await f.text(); const bal = t.match(/<BALAMT>\s*([-\d.,]+)/i);
  const lancs = [...t.matchAll(/<STMTTRN>([\s\S]*?)(?:<\/STMTTRN>|(?=<STMTTRN>)|(?=<\/BANKTRANLIST>))/gi)].map(m => {
    const b = m[1]; const g = k => (b.match(new RegExp('<' + k + '>\\s*([^<\\r\\n]+)', 'i')) || [])[1];
    const d = (g('DTPOSTED') || '').slice(0, 8);
    return { data: d ? d.slice(0, 4) + '-' + d.slice(4, 6) + '-' + d.slice(6, 8) : hoje(), desc: (g('MEMO') || g('NAME') || 'Lançamento').trim(), valor: r2(parseFloat((g('TRNAMT') || '0').replace(',', '.'))) };
  }).filter(l => !isNaN(l.valor));
  if (!lancs.length && !bal) { toast('Não encontrei lançamentos nesse arquivo. Confirme se é um OFX.', 'b'); return; }
  const n = await q(sb.rpc('importar_extrato', { p_lancs: lancs, p_saldo: bal ? parseFloat(bal[1].replace(',', '.')) : null }));
  await atualizar(n + ' lançamentos importados. Saldo atualizado.');
}

/* ================= Eventos ================= */
document.addEventListener('click', e => {
  const t = e.target.closest('[data-tab],[data-a],[data-fsub]'); if (!t || !S) return;
  if (t.dataset.tab) { tab = t.dataset.tab; return render(); }
  if (t.dataset.fsub) { fsub = t.dataset.fsub; return render(); }
  const a = t.dataset.a, id = t.dataset.id, cn = t.dataset.cnpj;
  if (a === 'editRegra') { editRegra = editRegra === cn ? null : cn; return render(); }
  if (a === 'csv') {
    const csv = 'representante;superior;a_pagar;ja_pago\n' + S.reps.map(r => [r.nome, rep(r.parent)?.nome || '', saldo(r.id, 'a pagar').toFixed(2).replace('.', ','), saldo(r.id, 'paga').toFixed(2).replace('.', ',')].join(';')).join('\n');
    navigator.clipboard.writeText(csv).then(() => toast('CSV copiado para a área de transferência.', 'ok'), () => toast('Não foi possível copiar neste navegador.', 'b')); return;
  }
  t.disabled = true;
  acao(async () => {
    if (a === 'receber') { await q(sb.rpc('receber_parcela', { p_parcela: id, p_origem: 'manual' })); return atualizar('Recebimento registrado. Comissões geradas.'); }
    if (a === 'cancelar') { await q(sb.rpc('cancelar_parcela', { p_parcela: id })); return atualizar('Parcela cancelada. Comissões não pagas estornadas; as pagas viram desconto.', 'w'); }
    if (a === 'pagar') { const v = await q(sb.rpc('pagar_representante', { p_rep: id })); return atualizar('Pagamento de ' + brl(v) + ' registrado para ' + rep(id).nome + '.'); }
    if (a === 'reproc') { const n = await q(sb.rpc('reprocessar_comissoes')); return atualizar(n ? n + ' comissões a pagar recalculadas.' : 'Nada mudou: as comissões a pagar já estão nas regras atuais.'); }
    if (a === 'limpaRegra') { await q(sb.from('regras_cliente').delete().eq('cnpj', cn)); return atualizar('Regra específica removida.'); }
    if (a === 'aceitar') { await q(sb.rpc('decidir_cliente', { p_cnpj: cn, p_aceitar: true })); return atualizar('Cliente aceito.'); }
    if (a === 'recusar') {
      const m = ($('mot-' + cn)?.value || '').trim(); if (!m) { toast('Informe o motivo da recusa.', 'w'); t.disabled = false; return; }
      await q(sb.rpc('decidir_cliente', { p_cnpj: cn, p_aceitar: false, p_motivo: m })); return atualizar('Cliente recusado. O representante verá o motivo.', 'w');
    }
    if (a === 'remGestor') { await q(sb.from('gestores').delete().eq('email', t.dataset.email)); return atualizar('Gestor removido.'); }
    if (a === 'ofx') { await importarOfx(); t.disabled = false; }
  });
});
document.addEventListener('change', e => {
  const el = e.target; if (!S) return;
  if (el.dataset.tx !== undefined) {
    const regimes = JSON.parse(JSON.stringify(S.config.regimes));
    regimes[S.config.regime].itens[+el.dataset.tx].v = Math.min(100, Math.max(0, parseFloat(el.value) || 0));
    return acao(async () => { await q(sb.from('config').update({ regimes }).eq('id', 1)); await atualizar('Alíquota salva.'); });
  }
  if (el.dataset.regra) {
    const c = cliente(el.dataset.regra), r = rep(el.dataset.id), v = clampPct(el.value);
    return acao(async () => {
      if (v === r.pct) await q(sb.from('regras_cliente').delete().eq('cnpj', c.cnpj).eq('rep_id', r.id));
      else await q(sb.from('regras_cliente').upsert({ cnpj: c.cnpj, rep_id: r.id, pct: v }));
      await carregar(); render();
      if (!cadeiaValida(c.repId, c.cnpj)) toast('Atenção: na cadeia deste cliente alguém abaixo ficou com % maior que o de cima, ou o total passou de ' + MAXPCT + '%. Recebimentos ficam bloqueados até corrigir.', 'w');
      else toast('Regra específica salva.', 'ok');
    });
  }
  if (el.dataset.e && el.dataset.id) {
    const campo = el.dataset.e; let valor = el.value;
    if (campo === 'pct') valor = clampPct(valor);
    if (campo === 'superior_id') valor = valor || null;
    if (campo === 'email') valor = valor.trim().toLowerCase() || null;
    if (campo === 'nome' && !valor.trim()) return render();
    return acao(async () => { await q(sb.from('representantes').update({ [campo]: valor }).eq('id', el.dataset.id)); await atualizar('Alteração salva.'); });
  }
});
document.addEventListener('submit', e => {
  e.preventDefault(); if (!S) return;
  const f = e.target, d = Object.fromEntries(new FormData(f));
  const btn = f.querySelector('button'); if (btn) btn.disabled = true;
  acao(async () => {
    if (f.dataset.f === 'rep') {
      await q(sb.from('representantes').insert({ nome: d.nome.trim(), email: d.email.trim().toLowerCase(), superior_id: d.parent || null, pct: clampPct(d.pct) }));
      return atualizar('Representante cadastrado. Ele já pode entrar com o e-mail ' + d.email + '.');
    }
    if (f.dataset.f === 'cfg') { await q(sb.from('config').update({ regime: d.regime }).eq('id', 1)); return atualizar('Regime alterado.'); }
    if (f.dataset.f === 'gestor') { await q(sb.from('gestores').insert({ email: d.email.trim().toLowerCase() })); return atualizar('Gestor adicionado.'); }
    if (f.dataset.f === 'cli') {
      const r = await q(sb.rpc('cadastrar_cliente', { p_cnpj: d.cnpj, p_razao: d.razao, p_rep: d.repId || null }));
      if (r === 'conflito') return atualizar(user() === 'admin' ? 'Conflito: esse CNPJ já pertence a outra carteira. Alerta registrado.' : 'Este CNPJ já pertence a outra carteira. A administração foi avisada.', 'b');
      if (r === 'ja_na_carteira') return atualizar('Este cliente já está nesta carteira.', 'w');
      return atualizar(r === 'aprovado' ? 'Cliente cadastrado.' : 'Solicitação enviada. O cliente entra na carteira após o aceite do gestor.');
    }
    if (f.dataset.f === 'nf') {
      await q(sb.rpc('lancar_nota', { p_numero: d.numero.trim(), p_cnpj: d.cnpj, p_descricao: d.desc, p_total: +d.total, p_parcelas: parseInt(d.np) || 1, p_venc: d.venc || hoje(), p_origem: 'manual' }));
      return atualizar('NF ' + d.numero + ' lançada.');
    }
  });
});

/* ================= Login ================= */
function telaLogin(msg) {
  S = null; $('tabs').innerHTML = ''; $('quem').textContent = ''; $('sair').classList.add('hide');
  $('app').innerHTML = `<div class="card" id="login"><h2>Entrar</h2>
    <p class="muted">Digite seu e-mail. Você receberá um link de acesso — sem senha.</p>
    <form data-login><input name="email" type="email" required placeholder="seu-email@empresa.com.br"><button class="b" style="width:100%">Enviar link de acesso</button></form>
    <p class="note" id="loginmsg">${esc(msg || '')}</p></div>`;
  $('app').querySelector('form[data-login]').addEventListener('submit', async ev => {
    ev.preventDefault(); ev.stopPropagation();
    const email = new FormData(ev.target).get('email').trim().toLowerCase();
    const { error } = await sb.auth.signInWithOtp({ email, options: { emailRedirectTo: location.origin + location.pathname } });
    $('loginmsg').textContent = error ? 'Não foi possível enviar: ' + erroMsg(error) : 'Pronto! Abra o e-mail enviado para ' + email + ' e clique no link.';
  });
}
async function iniciar(session) {
  if (!session) return telaLogin();
  try {
    eu = await q(sb.rpc('meu_papel'));
    if (!eu.papel) { await sb.auth.signOut(); return telaLogin('O e-mail ' + eu.email + ' não está cadastrado no portal. Fale com o gestor.'); }
    $('quem').textContent = (eu.nome || eu.email) + (eu.papel === 'gestor' ? ' · gestor' : '');
    $('sair').classList.remove('hide');
    await carregar(); render();
  } catch (e) { $('app').innerHTML = `<div class="card"><h2>Erro ao carregar</h2><p>${esc(erroMsg(e))}</p><p class="note">Confira se o arquivo supabase/instalar.sql foi executado no Supabase.</p></div>`; }
}
$('sair').addEventListener('click', async () => { await sb.auth.signOut(); telaLogin(); });
let iniciado = false;
sb.auth.onAuthStateChange((ev, session) => {
  if (ev === 'SIGNED_OUT') { iniciado = false; return telaLogin(); }
  if ((ev === 'INITIAL_SESSION' || ev === 'SIGNED_IN') && !iniciado) { iniciado = !!session; setTimeout(() => iniciar(session), 0); }
});
