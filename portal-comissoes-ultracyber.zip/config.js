// Preencha com os dados do seu projeto Supabase
// (Supabase → Project Settings → API). A chave "anon public" pode ficar aqui:
// ela é pública por natureza e o banco só libera o que cada usuário pode ver.
// NUNCA coloque aqui a chave "service_role".
window.PORTAL_CONFIG = {
  SUPABASE_URL: "",
  SUPABASE_ANON_KEY: ""
};
