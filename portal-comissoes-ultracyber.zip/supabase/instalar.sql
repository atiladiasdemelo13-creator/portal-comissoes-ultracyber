-- =====================================================================
-- Portal de Comissões — Ultra Cyber Security
-- Instalação do banco de dados (Supabase / PostgreSQL)
--
-- COMO USAR: no Supabase, abra "SQL Editor" → "New query", cole este
-- arquivo inteiro e clique em "Run". Depois rode o bloco do final
-- (CADASTRO DO GESTOR) trocando o e-mail pelo seu.
--
-- Pode ser executado de novo sem perder dados (usa IF NOT EXISTS /
-- CREATE OR REPLACE), exceto o bloco de dados de exemplo, que é opcional.
-- =====================================================================

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------
-- TABELAS
-- ---------------------------------------------------------------------
create table if not exists gestores (
  email text primary key
);

create table if not exists config (
  id int primary key default 1 check (id = 1),
  regime text not null default 'simples',
  regimes jsonb not null,
  saldo_inicial numeric(14,2) not null default 0,
  banco_nome text not null default 'Itaú — conta PJ',
  banco_fonte text not null default 'portal',
  banco_importado_em date
);

create table if not exists representantes (
  id uuid primary key default gen_random_uuid(),
  nome text not null,
  email text unique,
  superior_id uuid references representantes(id) on delete restrict,
  pct numeric(5,2) not null default 0,
  ativo boolean not null default true,
  criado_em timestamptz not null default now()
);

create table if not exists clientes (
  cnpj text primary key check (cnpj ~ '^\d{14}$'),
  razao text not null,
  rep_id uuid not null references representantes(id),
  status text not null default 'pendente' check (status in ('pendente','aprovado','recusado')),
  motivo text,
  solicitado_em date not null default current_date,
  decidido_em date
);

create table if not exists regras_cliente (
  cnpj text references clientes(cnpj) on delete cascade,
  rep_id uuid references representantes(id) on delete cascade,
  pct numeric(5,2) not null check (pct >= 0 and pct <= 50),
  primary key (cnpj, rep_id)
);

create table if not exists conflitos (
  id uuid primary key default gen_random_uuid(),
  cnpj text not null,
  dono uuid references representantes(id),
  tentou uuid references representantes(id),
  quando date not null default current_date
);

create table if not exists notas (
  id uuid primary key default gen_random_uuid(),
  numero text unique not null,
  cnpj text not null references clientes(cnpj),
  rep_id uuid not null references representantes(id),
  descricao text,
  total numeric(14,2) not null check (total > 0),
  origem text not null default 'manual',
  erp_id text,
  criada_em timestamptz not null default now()
);

create table if not exists parcelas (
  id uuid primary key default gen_random_uuid(),
  nota_id uuid not null references notas(id) on delete cascade,
  n int not null,
  valor numeric(14,2) not null,
  vencimento date not null,
  status text not null default 'aberta' check (status in ('aberta','recebida','cancelada')),
  recebida_em date,
  origem_baixa text,
  unique (nota_id, n)
);

create table if not exists comissoes (
  id uuid primary key default gen_random_uuid(),
  parcela_id uuid not null references parcelas(id) on delete cascade,
  nota_id uuid not null references notas(id) on delete cascade,
  parcela_n int not null,
  rep_id uuid not null references representantes(id),
  nivel int not null,
  tipo text not null,
  recebido numeric(14,2) not null,
  regime text not null,
  taxa numeric(6,2) not null,
  impostos numeric(14,2) not null,
  base numeric(14,2) not null,
  pct_global numeric(5,2) not null,
  pct_abaixo numeric(5,2) not null,
  pct numeric(5,2) not null,
  especifica boolean not null default false,
  valor numeric(14,2) not null,
  status text not null default 'a pagar' check (status in ('a pagar','paga','estornada')),
  estorno boolean not null default false,
  paga_em date,
  criada_em timestamptz not null default now()
);

create table if not exists banco_lancamentos (
  id uuid primary key default gen_random_uuid(),
  data date not null,
  descricao text not null,
  valor numeric(14,2) not null,
  origem text not null default 'portal'
);

create table if not exists auditoria (
  id bigserial primary key,
  quando timestamptz not null default now(),
  quem text,
  texto text not null
);

create index if not exists ix_rep_superior on representantes(superior_id);
create index if not exists ix_cli_rep on clientes(rep_id);
create index if not exists ix_nota_rep on notas(rep_id);
create index if not exists ix_parc_nota on parcelas(nota_id);
create index if not exists ix_com_rep on comissoes(rep_id);
create index if not exists ix_com_parc on comissoes(parcela_id);

-- Configuração inicial (alíquotas ILUSTRATIVAS — confirmar com a contabilidade)
insert into config (id, regime, regimes) values (1, 'simples', '{
  "simples":   {"nome":"Simples Nacional","itens":[{"n":"Alíquota efetiva do DAS","v":6}]},
  "presumido": {"nome":"Lucro Presumido","itens":[{"n":"PIS","v":0.65},{"n":"COFINS","v":3},{"n":"IRPJ (32% × 15%)","v":4.8},{"n":"CSLL (32% × 9%)","v":2.88},{"n":"ISS","v":5}]},
  "real":      {"nome":"Lucro Real","itens":[{"n":"PIS","v":1.65},{"n":"COFINS","v":7.6},{"n":"ISS","v":5},{"n":"IRPJ/CSLL estimado","v":0}]}
}'::jsonb) on conflict (id) do nothing;

-- ---------------------------------------------------------------------
-- QUEM É O USUÁRIO LOGADO
-- ---------------------------------------------------------------------
create or replace function meu_email() returns text
language sql stable as $$ select lower(coalesce(auth.jwt() ->> 'email', '')) $$;

create or replace function eh_gestor() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from gestores where lower(email) = meu_email())
$$;

create or replace function meu_rep() returns uuid
language sql stable security definer set search_path = public as $$
  select id from representantes where lower(email) = meu_email() and ativo limit 1
$$;

create or replace function descendentes(p_rep uuid) returns setof uuid
language sql stable security definer set search_path = public as $$
  with recursive d as (
    select id from representantes where id = p_rep
    union
    select r.id from representantes r join d on r.superior_id = d.id
  ) select id from d
$$;

-- pode ver o representante X? (gestor vê todos; representante vê a si e abaixo)
create or replace function pode_ver_rep(p_rep uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select eh_gestor() or (meu_rep() is not null and p_rep in (select descendentes(meu_rep())))
$$;

create or replace function meu_papel() returns json
language sql stable security definer set search_path = public as $$
  select json_build_object(
    'email', meu_email(),
    'papel', case when eh_gestor() then 'gestor' when meu_rep() is not null then 'representante' else null end,
    'rep_id', meu_rep(),
    'nome', (select nome from representantes where id = meu_rep()))
$$;

create or replace function registrar(p_texto text) returns void
language sql security definer set search_path = public as $$
  insert into auditoria (quem, texto) values (nullif(meu_email(), ''), p_texto)
$$;

-- ---------------------------------------------------------------------
-- REGRAS DE CÁLCULO
-- ---------------------------------------------------------------------
create or replace function taxa_atual() returns numeric
language sql stable security definer set search_path = public as $$
  select coalesce(round(sum((i ->> 'v')::numeric), 2), 0)
  from config c, jsonb_array_elements(c.regimes -> c.regime -> 'itens') i
$$;

create or replace function regime_nome() returns text
language sql stable security definer set search_path = public as $$
  select regimes -> regime ->> 'nome' from config where id = 1
$$;

-- Cadeia de comissão: vendedor + superiores. Cada um recebe (o seu % − o % de quem está logo abaixo).
-- Regra específica do cliente (regras_cliente) se sobressai ao cadastro só naquele cliente.
create or replace function cadeia(p_rep uuid, p_cnpj text)
returns table (rep_id uuid, nivel int, pct_global numeric, pct_abaixo numeric, pct numeric, especifica boolean)
language sql stable security definer set search_path = public as $$
  with recursive up as (
    select r.id, r.superior_id, 0 as nivel from representantes r where r.id = p_rep
    union all
    select r.id, r.superior_id, up.nivel + 1 from representantes r join up on r.id = up.superior_id
  ), p as (
    select up.id, up.nivel, coalesce(rc.pct, r.pct) as pg, (rc.pct is not null) as esp
    from up join representantes r on r.id = up.id
    left join regras_cliente rc on rc.cnpj = p_cnpj and rc.rep_id = up.id
  )
  select id, nivel, pg,
         coalesce(lag(pg) over (order by nivel), 0),
         greatest(0, pg - coalesce(lag(pg) over (order by nivel), 0)),
         esp
  from p order by nivel
$$;

create or replace function cadeia_valida(p_rep uuid, p_cnpj text) returns boolean
language sql stable security definer set search_path = public as $$
  select not exists (select 1 from cadeia(p_rep, p_cnpj) c where c.pct_global < c.pct_abaixo)
     and coalesce((select max(c.pct_global) from cadeia(p_rep, p_cnpj) c), 0) <= 50
$$;

create or replace function cnpj_valido(c text) returns boolean
language plpgsql immutable as $$
declare s int; i int; d1 int; d2 int;
  w1 int[] := array[5,4,3,2,9,8,7,6,5,4,3,2];
  w2 int[] := array[6,5,4,3,2,9,8,7,6,5,4,3,2];
begin
  if c !~ '^\d{14}$' or c ~ '^(\d)\1{13}$' then return false; end if;
  s := 0; for i in 1..12 loop s := s + substr(c, i, 1)::int * w1[i]; end loop;
  d1 := case when s % 11 < 2 then 0 else 11 - s % 11 end;
  s := 0; for i in 1..13 loop s := s + substr(c, i, 1)::int * w2[i]; end loop;
  d2 := case when s % 11 < 2 then 0 else 11 - s % 11 end;
  return d1 = substr(c, 13, 1)::int and d2 = substr(c, 14, 1)::int;
end $$;

-- Validação da rede: ninguém acima de 50%, ninguém com % maior que o superior,
-- ninguém abaixo de quem está abaixo dele, sem ciclos.
create or replace function trg_rep_valida() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_sup numeric; v_filho numeric;
begin
  if new.pct < 0 or new.pct > 50 then raise exception 'O percentual deve ficar entre 0%% e 50%%.'; end if;
  if new.superior_id is not null then
    if new.superior_id = new.id or (tg_op = 'UPDATE' and new.superior_id in (select descendentes(new.id))) then
      raise exception 'Superior inválido: criaria um ciclo na rede.';
    end if;
    select pct into v_sup from representantes where id = new.superior_id;
    if new.pct > v_sup then raise exception 'O percentual de % (% %%) não pode ser maior que o do superior (% %%).', new.nome, new.pct, v_sup; end if;
  end if;
  if tg_op = 'UPDATE' then
    select max(pct) into v_filho from representantes where superior_id = new.id;
    if v_filho is not null and new.pct < v_filho then
      raise exception 'O percentual de % não pode ficar abaixo de quem está abaixo dele (% %%). Reduza primeiro os de baixo.', new.nome, v_filho;
    end if;
    if new.pct <> old.pct then perform registrar('% global de ' || new.nome || ': ' || old.pct || '% → ' || new.pct || '%'); end if;
    if new.superior_id is distinct from old.superior_id then perform registrar('Superior de ' || new.nome || ' alterado'); end if;
  else
    perform registrar('Novo representante: ' || new.nome || ' (' || new.pct || '%)');
  end if;
  return new;
end $$;
drop trigger if exists rep_valida on representantes;
create trigger rep_valida before insert or update on representantes for each row execute function trg_rep_valida();

create or replace function trg_regra_audit() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform registrar('Regra específica do cliente ' || coalesce(new.cnpj, old.cnpj) || ' — ' ||
    (select nome from representantes where id = coalesce(new.rep_id, old.rep_id)) || ': ' ||
    coalesce(old.pct::text || '%', 'padrão') || ' → ' || coalesce(new.pct::text || '%', 'padrão'));
  return coalesce(new, old);
end $$;
drop trigger if exists regra_audit on regras_cliente;
create trigger regra_audit after insert or update or delete on regras_cliente for each row execute function trg_regra_audit();

create or replace function trg_config_audit() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.regime <> old.regime then perform registrar('Regime: ' || (old.regimes -> old.regime ->> 'nome') || ' → ' || (new.regimes -> new.regime ->> 'nome')); end if;
  if new.regimes <> old.regimes then perform registrar('Alíquotas alteradas'); end if;
  return new;
end $$;
drop trigger if exists config_audit on config;
create trigger config_audit after update on config for each row execute function trg_config_audit();

-- ---------------------------------------------------------------------
-- OPERAÇÕES (chamadas pelo site)
-- ---------------------------------------------------------------------
create or replace function exige_gestor() returns void
language plpgsql stable security definer set search_path = public as $$
begin if not eh_gestor() then raise exception 'Apenas o gestor pode fazer isso.'; end if; end $$;

-- Cadastro / solicitação de cliente. Representante: entra como pendente. Gestor: já aprovado.
create or replace function cadastrar_cliente(p_cnpj text, p_razao text, p_rep uuid default null) returns text
language plpgsql security definer set search_path = public as $$
declare v_cnpj text := regexp_replace(coalesce(p_cnpj, ''), '\D', '', 'g'); v_rep uuid; ex clientes; v_g boolean := eh_gestor();
begin
  if not cnpj_valido(v_cnpj) then raise exception 'CNPJ inválido.'; end if;
  if coalesce(trim(p_razao), '') = '' then raise exception 'Informe a razão social.'; end if;
  v_rep := case when v_g then p_rep else meu_rep() end;
  if v_rep is null then raise exception 'Representante não identificado.'; end if;
  select * into ex from clientes where cnpj = v_cnpj;
  if found and ex.status <> 'recusado' then
    if ex.rep_id = v_rep then return 'ja_na_carteira'; end if;
    insert into conflitos (cnpj, dono, tentou) values (v_cnpj, ex.rep_id, v_rep);
    perform registrar('Conflito de carteira: CNPJ ' || v_cnpj);
    return 'conflito';
  end if;
  if found then delete from clientes where cnpj = v_cnpj; end if;
  insert into clientes (cnpj, razao, rep_id, status, decidido_em)
  values (v_cnpj, trim(p_razao), v_rep, case when v_g then 'aprovado' else 'pendente' end, case when v_g then current_date end);
  perform registrar(case when v_g then 'Cliente cadastrado pelo gestor: ' else 'Solicitação de cliente: ' end || trim(p_razao));
  return case when v_g then 'aprovado' else 'pendente' end;
end $$;

create or replace function decidir_cliente(p_cnpj text, p_aceitar boolean, p_motivo text default null) returns void
language plpgsql security definer set search_path = public as $$
declare c clientes;
begin
  perform exige_gestor();
  select * into c from clientes where cnpj = p_cnpj for update;
  if not found or c.status <> 'pendente' then raise exception 'Solicitação não encontrada ou já decidida.'; end if;
  if not p_aceitar and coalesce(trim(p_motivo), '') = '' then raise exception 'Informe o motivo da recusa.'; end if;
  update clientes set status = case when p_aceitar then 'aprovado' else 'recusado' end,
    motivo = case when p_aceitar then null else trim(p_motivo) end, decidido_em = current_date where cnpj = p_cnpj;
  perform registrar(case when p_aceitar then 'Cliente aceito: ' else 'Cliente recusado: ' end || c.razao || coalesce(' — ' || nullif(trim(p_motivo), ''), ''));
end $$;

create or replace function lancar_nota(p_numero text, p_cnpj text, p_descricao text, p_total numeric, p_parcelas int, p_venc date, p_origem text default 'manual')
returns uuid language plpgsql security definer set search_path = public as $$
declare c clientes; v_id uuid; v_base numeric; i int; v_np int := greatest(1, least(coalesce(p_parcelas, 1), 60));
begin
  perform exige_gestor();
  select * into c from clientes where cnpj = p_cnpj;
  if not found or c.status <> 'aprovado' then raise exception 'O cliente precisa estar aprovado.'; end if;
  if exists (select 1 from notas where numero = p_numero) then raise exception 'Já existe uma NF com esse número.'; end if;
  insert into notas (numero, cnpj, rep_id, descricao, total, origem) values (p_numero, p_cnpj, c.rep_id, p_descricao, round(p_total, 2), coalesce(p_origem, 'manual'))
  returning id into v_id;
  v_base := floor(p_total / v_np * 100) / 100;
  for i in 1..v_np loop
    insert into parcelas (nota_id, n, valor, vencimento)
    values (v_id, i, case when i = v_np then round(p_total - v_base * (v_np - 1), 2) else v_base end, coalesce(p_venc, current_date) + 30 * (i - 1));
  end loop;
  perform registrar('NF ' || p_numero || ' lançada (' || p_total || ')');
  return v_id;
end $$;

create or replace function receber_parcela(p_parcela uuid, p_origem text default 'manual') returns void
language plpgsql security definer set search_path = public as $$
declare v_p parcelas; v_n notas; v_tx numeric := taxa_atual(); v_reg text := regime_nome(); v_imp numeric; v_base numeric; c record;
begin
  perform exige_gestor();
  select * into v_p from parcelas where id = p_parcela for update;
  if not found or v_p.status <> 'aberta' then raise exception 'Parcela não está em aberto.'; end if;
  select * into v_n from notas where id = v_p.nota_id;
  if v_tx <= 0 then raise exception 'Defina a alíquota de impostos do regime antes de registrar recebimentos.'; end if;
  if not cadeia_valida(v_n.rep_id, v_n.cnpj) then raise exception 'A cadeia de percentuais deste cliente está inconsistente. Corrija antes.'; end if;
  update parcelas set status = 'recebida', recebida_em = current_date, origem_baixa = coalesce(p_origem, 'manual') where id = p_parcela;
  v_imp := round(v_p.valor * v_tx / 100, 2);
  v_base := v_p.valor - v_imp;
  for c in select * from cadeia(v_n.rep_id, v_n.cnpj) loop
    if c.pct > 0 then
      insert into comissoes (parcela_id, nota_id, parcela_n, rep_id, nivel, tipo, recebido, regime, taxa, impostos, base, pct_global, pct_abaixo, pct, especifica, valor)
      values (v_p.id, v_n.id, v_p.n, c.rep_id, c.nivel, case when c.nivel = 0 then 'Venda direta' else 'Diferença de rede' end,
              v_p.valor, v_reg, v_tx, v_imp, v_base, c.pct_global, c.pct_abaixo, c.pct, c.especifica, round(v_base * c.pct / 100, 2));
    end if;
  end loop;
  insert into banco_lancamentos (data, descricao, valor, origem)
  values (current_date, 'Recebimento NF ' || v_n.numero || ' — ' || v_p.n || 'ª parcela', v_p.valor, coalesce(p_origem, 'manual'));
  perform registrar('Recebimento NF ' || v_n.numero || ' parcela ' || v_p.n || ' (' || v_p.valor || ') — baixa ' || coalesce(p_origem, 'manual'));
end $$;

create or replace function cancelar_parcela(p_parcela uuid) returns void
language plpgsql security definer set search_path = public as $$
declare v_p parcelas; v_n notas;
begin
  perform exige_gestor();
  select * into v_p from parcelas where id = p_parcela for update;
  if not found or v_p.status = 'cancelada' then raise exception 'Parcela já cancelada.'; end if;
  select * into v_n from notas where id = v_p.nota_id;
  if v_p.status = 'recebida' then
    insert into comissoes (parcela_id, nota_id, parcela_n, rep_id, nivel, tipo, recebido, regime, taxa, impostos, base, pct_global, pct_abaixo, pct, especifica, valor, status, estorno)
    select parcela_id, nota_id, parcela_n, rep_id, nivel, 'Estorno — ' || tipo, recebido, regime, taxa, impostos, base, pct_global, pct_abaixo, pct, especifica, -valor, 'a pagar', true
    from comissoes where parcela_id = p_parcela and status = 'paga' and not estorno;
    update comissoes set status = 'estornada' where parcela_id = p_parcela and status = 'a pagar' and not estorno;
    insert into banco_lancamentos (data, descricao, valor, origem)
    values (current_date, 'Estorno recebimento NF ' || v_n.numero || ' — ' || v_p.n || 'ª parcela', -v_p.valor, 'portal');
  end if;
  update parcelas set status = 'cancelada' where id = p_parcela;
  perform registrar('Cancelamento NF ' || v_n.numero || ' parcela ' || v_p.n);
end $$;

create or replace function pagar_representante(p_rep uuid) returns numeric
language plpgsql security definer set search_path = public as $$
declare v_tot numeric; v_nome text;
begin
  perform exige_gestor();
  select coalesce(sum(valor), 0) into v_tot from comissoes where rep_id = p_rep and status = 'a pagar';
  if v_tot <= 0 then raise exception 'Saldo líquido não positivo — nada a pagar.'; end if;
  select nome into v_nome from representantes where id = p_rep;
  update comissoes set status = 'paga', paga_em = current_date where rep_id = p_rep and status = 'a pagar';
  insert into banco_lancamentos (data, descricao, valor, origem) values (current_date, 'Pagamento de comissão — ' || v_nome, -v_tot, 'portal');
  perform registrar('Pagamento ' || v_tot || ' a ' || v_nome);
  return v_tot;
end $$;

create or replace function reprocessar_comissoes() returns int
language plpgsql security definer set search_path = public as $$
declare r record; c record; v_tx numeric := taxa_atual(); v_reg text := regime_nome(); v_imp numeric; v_base numeric; v_val numeric; v_n int := 0;
begin
  perform exige_gestor();
  for r in select cm.*, n.rep_id as vendedor, n.cnpj from comissoes cm join notas n on n.id = cm.nota_id
           where cm.status = 'a pagar' and not cm.estorno loop
    select * into c from cadeia(r.vendedor, r.cnpj) x where x.rep_id = r.rep_id;
    if not found then continue; end if;
    v_imp := round(r.recebido * v_tx / 100, 2); v_base := r.recebido - v_imp; v_val := round(v_base * c.pct / 100, 2);
    if v_val <> r.valor or v_tx <> r.taxa then
      update comissoes set regime = v_reg, taxa = v_tx, impostos = v_imp, base = v_base, pct_global = c.pct_global,
        pct_abaixo = c.pct_abaixo, pct = c.pct, especifica = c.especifica, valor = v_val where id = r.id;
      v_n := v_n + 1;
    end if;
  end loop;
  perform registrar('Gestor reprocessou comissões a pagar (' || v_n || ' linhas alteradas)');
  return v_n;
end $$;

-- Importação de extrato OFX: substitui os lançamentos e acerta o saldo
create or replace function importar_extrato(p_lancs jsonb, p_saldo numeric) returns int
language plpgsql security definer set search_path = public as $$
declare v_soma numeric; v_n int;
begin
  perform exige_gestor();
  delete from banco_lancamentos;
  insert into banco_lancamentos (data, descricao, valor, origem)
  select (l ->> 'data')::date, coalesce(l ->> 'desc', 'Lançamento'), (l ->> 'valor')::numeric, 'extrato OFX' from jsonb_array_elements(p_lancs) l;
  get diagnostics v_n = row_count;
  select coalesce(sum(valor), 0) into v_soma from banco_lancamentos;
  update config set saldo_inicial = coalesce(p_saldo, v_soma) - v_soma, banco_fonte = 'ofx', banco_importado_em = current_date where id = 1;
  perform registrar('Extrato OFX importado (' || v_n || ' lançamentos)');
  return v_n;
end $$;

-- ---------------------------------------------------------------------
-- SEGURANÇA (Row Level Security): cada um só enxerga o que pode
-- ---------------------------------------------------------------------
alter table gestores enable row level security;
alter table config enable row level security;
alter table representantes enable row level security;
alter table clientes enable row level security;
alter table regras_cliente enable row level security;
alter table conflitos enable row level security;
alter table notas enable row level security;
alter table parcelas enable row level security;
alter table comissoes enable row level security;
alter table banco_lancamentos enable row level security;
alter table auditoria enable row level security;

revoke all on all tables in schema public from anon;
revoke all on all functions in schema public from anon, public;
revoke all on all functions in schema public from authenticated;
-- só o necessário fica liberado para quem está logado (as demais funções são internas)
grant execute on function eh_gestor(), pode_ver_rep(uuid), meu_papel(),
  cadastrar_cliente(text, text, uuid), decidir_cliente(text, boolean, text),
  lancar_nota(text, text, text, numeric, int, date, text), receber_parcela(uuid, text),
  cancelar_parcela(uuid), pagar_representante(uuid), reprocessar_comissoes(),
  importar_extrato(jsonb, numeric) to authenticated;

do $$ declare t text; begin
  foreach t in array array['gestores','config','representantes','clientes','regras_cliente','conflitos','notas','parcelas','comissoes','banco_lancamentos','auditoria'] loop
    execute format('drop policy if exists p_sel on %I', t);
    execute format('drop policy if exists p_gestor on %I', t);
  end loop;
end $$;

-- Gestor: acesso total às tabelas de cadastro
create policy p_gestor on gestores for all to authenticated using (eh_gestor()) with check (eh_gestor());
create policy p_gestor on representantes for all to authenticated using (eh_gestor()) with check (eh_gestor());
create policy p_gestor on regras_cliente for all to authenticated using (eh_gestor()) with check (eh_gestor());
create policy p_gestor on conflitos for select to authenticated using (eh_gestor());
create policy p_gestor on banco_lancamentos for select to authenticated using (eh_gestor());
create policy p_gestor on auditoria for select to authenticated using (eh_gestor());

-- Config: todos logados leem (o representante vê a taxa de imposto); só o gestor altera
create policy p_sel on config for select to authenticated using (true);
create policy p_gestor on config for update to authenticated using (eh_gestor()) with check (eh_gestor());

-- Representante vê a si e quem está abaixo — nunca quem está acima
create policy p_sel on representantes for select to authenticated using (pode_ver_rep(id));
create policy p_sel on clientes for select to authenticated using (pode_ver_rep(rep_id));
create policy p_sel on regras_cliente for select to authenticated using (pode_ver_rep(rep_id));
create policy p_sel on notas for select to authenticated using (pode_ver_rep(rep_id));
create policy p_sel on parcelas for select to authenticated using (exists (select 1 from notas n where n.id = nota_id and pode_ver_rep(n.rep_id)));
create policy p_sel on comissoes for select to authenticated using (pode_ver_rep(rep_id));
-- notas, parcelas, comissões e clientes só mudam pelas funções acima (com validação)

-- =====================================================================
-- CADASTRO DO GESTOR — troque pelo seu e-mail e rode esta linha
-- =====================================================================
-- insert into gestores (email) values ('seu-email@empresa.com.br') on conflict do nothing;
